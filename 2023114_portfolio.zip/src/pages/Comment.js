import React from 'react'




function Comment() {
  return (
  <>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Optio consequuntur placeat laudantium voluptas inventore, asperiores quos, non quo molestiae quaerat quod assumenda. Qui, obcaecati. Similique ullam quas veniam consectetur. Consectetur!</p>
  </>
  )
}

export default Comment